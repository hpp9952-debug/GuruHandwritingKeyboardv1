# Guru Handwriting Keyboard V4

V4 is designed to look like a normal English QWERTY keyboard rather than a text composer.

Layout:
- QWERTYUIOP
- ASDFGHJKL
- ZXCVBNM
- Shift
- comma / space / backspace / enter
- 123 mode with numbers and symbols

The keyboard commits text directly into the focused app's text field, so WhatsApp keeps its normal message box.

A small ✍ button reads the current text through the InputConnection, renders it using the final Guru Handwriting TTF, and opens the Android share sheet so the handwriting PNG can be sent through WhatsApp or another app.

The final font is embedded at:
app/src/main/assets/GuruHandwriting.ttf

Build:
GitHub -> Actions -> Build Guru Handwriting Keyboard APK -> Run workflow.
