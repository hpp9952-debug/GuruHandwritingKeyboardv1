package com.guru.handwritingkeyboard;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.inputmethodservice.InputMethodService;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;

public class GuruKeyboardService extends InputMethodService {

    private Typeface guru;
    private LinearLayout root;
    private boolean shift = false;
    private boolean numbers = false;

    @Override
    public View onCreateInputView() {
        guru = Typeface.createFromAsset(getAssets(), "GuruHandwriting.ttf");

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(5), dp(4), dp(5), dp(5));
        root.setBackgroundColor(Color.rgb(230,230,230));

        buildKeyboard();
        return root;
    }

    private void buildKeyboard() {
        root.removeAllViews();

        // Compact toolbar, similar in purpose to a normal keyboard toolbar.
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);

        Button handwriting = key("✍", 18);
        handwriting.setContentDescription("Send as Guru handwriting");
        handwriting.setOnClickListener(v -> shareCurrentTextAsHandwriting());

        Button mode = key(numbers ? "ABC" : "123", 13);
        mode.setOnClickListener(v -> {
            numbers = !numbers;
            buildKeyboard();
        });

        toolbar.addView(handwriting, weight(1, 44));
        toolbar.addView(mode, weight(1, 44));

        root.addView(toolbar);

        if (numbers) {
            addRow("1 2 3 4 5 6 7 8 9 0".replace(" ", ""), false);
            addRow("@ # $ % & * - + ( )".replace(" ", ""), false);
            addRow("! ? : ; ' \" / , .".replace(" ", ""), false);
        } else {
            addRow("QWERTYUIOP", true);
            addRow("ASDFGHJKL", true);
            addRow("ZXCVBNM", true);
        }

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER);

        Button shiftKey = key("⇧", 18);
        shiftKey.setOnClickListener(v -> {
            shift = !shift;
            buildKeyboard();
        });

        Button comma = key(",", 18);
        comma.setOnClickListener(v -> commit(","));

        Button space = key("space", 12);
        space.setOnClickListener(v -> commit(" "));

        Button back = key("⌫", 18);
        back.setOnClickListener(v -> backspace());

        Button enter = key("↵", 18);
        enter.setOnClickListener(v -> commit("\n"));

        bottom.addView(shiftKey, weight(1, 56));
        bottom.addView(comma, weight(1, 56));
        bottom.addView(space, weight(3, 56));
        bottom.addView(back, weight(1, 56));
        bottom.addView(enter, weight(1, 56));

        root.addView(bottom);
    }

    private void addRow(String letters, boolean isLetters) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(1), dp(2), dp(1), dp(2));

        for (char c : letters.toCharArray()) {
            String value = String.valueOf(c);
            if (isLetters && !shift) {
                value = value.toLowerCase();
            }

            Button b = key(value, value.length() == 1 ? 18 : 13);
            final String commitValue = value;
            b.setOnClickListener(v -> commit(commitValue));
            row.addView(b, weight(1, 54));
        }

        root.addView(row);
    }

    private Button key(String text, float size) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(size);
        b.setTypeface(guru);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, 0, 0, 0);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setBackgroundResource(com.guru.handwritingkeyboard.R.drawable.key_bg);
        return b;
    }

    private LinearLayout.LayoutParams weight(float w, int heightDp) {
        return new LinearLayout.LayoutParams(0, dp(heightDp), w);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void commit(String text) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            ic.commitText(text, 1);
        }
    }

    private void backspace() {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            ic.deleteSurroundingText(1, 0);
        }
    }

    private String getCurrentText() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return "";

        ExtractedTextRequest request = new ExtractedTextRequest();
        request.token = 1;
        request.flags = 0;

        ExtractedText extracted = ic.getExtractedText(request, 0);
        if (extracted != null && extracted.text != null) {
            return extracted.text.toString();
        }

        CharSequence before = ic.getTextBeforeCursor(10000, 0);
        CharSequence after = ic.getTextAfterCursor(10000, 0);
        String a = before == null ? "" : before.toString();
        String b = after == null ? "" : after.toString();
        return a + b;
    }

    private void shareCurrentTextAsHandwriting() {
        String text = getCurrentText();

        if (TextUtils.isEmpty(text.trim())) {
            Toast.makeText(this, "Type a message first", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            File dir = new File(getCacheDir(), "guru");
            if (!dir.exists()) dir.mkdirs();

            File image = new File(dir, "guru_handwriting.png");

            int width = 1400;
            int pad = 90;
            int lineHeight = 105;

            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setTypeface(guru);
            paint.setTextSize(64);
            paint.setColor(Color.BLACK);

            String[] lines = text.split("\\n", -1);
            int height = Math.max(240, pad * 2 + lines.length * lineHeight);

            Bitmap bitmap = Bitmap.createBitmap(
                    width, height, Bitmap.Config.ARGB_8888);

            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(Color.WHITE);

            float y = pad + 64;
            for (String line : lines) {
                canvas.drawText(line, pad, y, paint);
                y += lineHeight;
            }

            FileOutputStream out = new FileOutputStream(image);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();

            Uri uri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    image);

            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("image/png");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                    Intent.FLAG_ACTIVITY_NEW_TASK);

            startActivity(Intent.createChooser(share, "Send Guru Handwriting"));

        } catch (Exception e) {
            Toast.makeText(this,
                    "Could not create handwriting image: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }
}
